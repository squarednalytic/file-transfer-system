const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const { generateLargeFile } = require('./file-generator');

const app = express();
const CLIENT_PORT = process.env.CLIENT_PORT || 8080;
const SERVER_URL = process.env.SERVER_URL || 'http://localhost:3000';
const CLIENT_ID = process.env.CLIENT_ID || `client-${Math.random().toString(36).substr(2, 9)}`;

app.use(express.json());

const config = {
    clientId: CLIENT_ID,
    clientUrl: `http://localhost:${CLIENT_PORT}`,
    filePath: path.join(process.env.HOME || process.env.USERPROFILE, 'file_to_download.txt'),
    serverUrl: SERVER_URL
};


function ensureFileExists() {
    if (!fs.existsSync(config.filePath)) {
        console.log('File not found. Generating 100MB file...');
        generateLargeFile(config.filePath, 100);
    } else {
        const stats = fs.statSync(config.filePath);
        const fileSizeMB = stats.size / (1024 * 1024);
        console.log(`File found: ${config.filePath}`);
        console.log(`File size: ${fileSizeMB.toFixed(2)}MB`);
        
        if (fileSizeMB < 99) {
            console.log('File size is less than 100MB. Regenerating...');
            generateLargeFile(config.filePath, 100);
        }
    }
}


async function registerWithServer() {
    try {
        const response = await axios.post(`${config.serverUrl}/register`, {
            clientId: config.clientId,
            clientUrl: config.clientUrl
        });
        
        console.log('Successfully registered with server');
        return true;
    } catch (error) {
        console.error('Failed to register with server:', error.message);
        return false;
    }
}


async function sendHeartbeat() {
    try {
        await axios.post(`${config.serverUrl}/heartbeat`, {
            clientId: config.clientId
        });
    } catch (error) {
        console.error('Heartbeat failed:', error.message);
    }
}


app.post('/request-upload', async (req, res) => {
    const { requestId, serverUrl } = req.body;
    
    console.log(`Upload request received: ${requestId}`);
    
    try {
        // Accept the request immediately
        res.json({ status: 'accepted' });
        
        // Then start the file upload process
        await uploadFileToServer(requestId, serverUrl || config.serverUrl);
    } catch (error) {
        console.error('Error handling upload request:', error.message);
    }
});


async function uploadFileToServer(requestId, targetServerUrl) {
    try {
        console.log(`Starting file upload for request: ${requestId}`);
        
        const formData = new FormData();
        formData.append('file', fs.createReadStream(config.filePath));
        formData.append('requestId', requestId);
        
        const response = await axios.post(`${targetServerUrl}/upload-file`, formData, {
            headers: {
                ...formData.getHeaders(),
            },
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
        });
        
        console.log('File uploaded successfully:', response.data);
        
        
        await axios.post(`${targetServerUrl}/download-complete`, {
            requestId,
            downloadUrl: response.data.downloadUrl
        });
        
    } catch (error) {
        console.error('Error uploading file:', error.message);
        
        // Try to notify server about failure
        try {
            await axios.post(`${targetServerUrl}/download-complete`, {
                requestId,
                error: error.message
            });
        } catch (notifyError) {
            console.error('Failed to notify server about upload error:', notifyError.message);
        }
    }
}


app.get('/status', (req, res) => {
    const stats = fs.statSync(config.filePath);
    
    res.json({
        clientId: config.clientId,
        status: 'online',
        file: {
            path: config.filePath,
            size: stats.size,
            sizeMB: (stats.size / (1024 * 1024)).toFixed(2),
            exists: true
        },
        server: config.serverUrl
    });
});

async function startClient() {
    
    ensureFileExists();
    
    
    app.listen(CLIENT_PORT, () => {
        console.log(`Client running on port ${CLIENT_PORT}`);
        console.log(`Client ID: ${config.clientId}`);
        console.log(`File location: ${config.filePath}`);
    });
    
    
    let registered = false;
    while (!registered) {
        registered = await registerWithServer();
        if (!registered) {
            console.log('Retrying registration in 10 seconds...');
            await new Promise(resolve => setTimeout(resolve, 10000));
        }
    }
    
    setInterval(sendHeartbeat, 30000);
    
    console.log('Client started successfully and registered with server');
}

if (require.main === module) {
    startClient().catch(console.error);
}

module.exports = { startClient, config };