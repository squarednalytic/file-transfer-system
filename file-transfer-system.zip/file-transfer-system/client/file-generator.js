const fs = require('fs');
const path = require('path');

function generateLargeFile(filePath, targetSizeMB = 100) {
    console.log(`Generating file: ${filePath}`);
    console.log(`Target size: ${targetSizeMB}MB`);
    
    const targetSizeBytes = targetSizeMB * 1024 * 1024;
    const chunk = 'A'.repeat(1024 * 1024); // 1MB chunk
    const writeStream = fs.createWriteStream(filePath);
    
    let bytesWritten = 0;
    
    function writeChunk() {
        let canContinue = true;
        
        while (bytesWritten < targetSizeBytes && canContinue) {
            const bytesToWrite = Math.min(chunk.length, targetSizeBytes - bytesWritten);
            const chunkToWrite = chunk.slice(0, bytesToWrite);
            
            canContinue = writeStream.write(chunkToWrite);
            bytesWritten += bytesToWrite;
            
            // Progress update every 10MB
            if (bytesWritten % (10 * 1024 * 1024) === 0) {
                const progress = ((bytesWritten / targetSizeBytes) * 100).toFixed(1);
                console.log(`Progress: ${progress}% (${(bytesWritten / (1024 * 1024)).toFixed(1)}MB)`);
            }
        }
        
        if (bytesWritten < targetSizeBytes) {
            writeStream.once('drain', writeChunk);
        } else {
            writeStream.end();
        }
    }
    
    writeStream.on('finish', () => {
        const stats = fs.statSync(filePath);
        console.log(`File generated successfully!`);
        console.log(`Final size: ${(stats.size / (1024 * 1024)).toFixed(2)}MB`);
        console.log(`Location: ${filePath}`);
    });
    
    writeStream.on('error', (err) => {
        console.error('Error generating file:', err);
    });
    
    writeChunk();
}

// Generate file if run directly
if (require.main === module) {
    const homeDir = process.env.HOME || process.env.USERPROFILE;
    const filePath = path.join(homeDir, 'file_to_download.txt');
    generateLargeFile(filePath, 100);
}

module.exports = { generateLargeFile };