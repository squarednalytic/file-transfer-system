class FileTransferDashboard {
    constructor() {
        this.serverUrl = window.location.origin;
        this.clients = [];
        this.downloads = [];
        this.init();
    }

    init() {
        this.loadData();
        this.setupEventListeners();
        this.startAutoRefresh();
    }

    setupEventListeners() {
        document.getElementById('refreshBtn').addEventListener('click', () => {
            this.loadData();
            this.showMessage('Data refreshed', 'success');
        });

        document.getElementById('downloadBtn').addEventListener('click', () => {
            this.initiateDownload();
        });

        document.getElementById('clientSelect').addEventListener('change', (e) => {
            document.getElementById('downloadBtn').disabled = !e.target.value;
        });
    }

    async loadData() {
        try {
            await Promise.all([
                this.loadClients(),
                this.loadDownloads()
            ]);
            this.updateStats();
            this.updateClientSelect();
        } catch (error) {
            this.showMessage('Failed to load data: ' + error.message, 'error');
        }
    }

    async loadClients() {
        const response = await fetch('/clients');
        const data = await response.json();
        this.clients = data.clients || [];
        this.renderClients();
    }

    async loadDownloads() {
        // Load recent downloads from server
        // This would need an endpoint to get download history
        this.renderDownloads();
    }

    renderClients() {
        const container = document.getElementById('clientList');
        
        if (this.clients.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-desktop"></i>
                    <p>No clients connected</p>
                </div>
            `;
            return;
        }

        container.innerHTML = this.clients.map(client => `
            <div class="client-card ${this.isClientOnline(client) ? '' : 'offline'}">
                <div class="client-header">
                    <span class="client-id">
                        <i class="fas fa-desktop"></i> ${client.id}
                    </span>
                    <span class="client-status ${this.isClientOnline(client) ? 'status-online' : 'status-offline'}">
                        ${this.isClientOnline(client) ? 'Online' : 'Offline'}
                    </span>
                </div>
                <div class="client-details">
                    <div>
                        <strong>URL:</strong> ${client.url}
                    </div>
                    <div>
                        <strong>Last Seen:</strong> ${new Date(client.lastSeen).toLocaleString()}
                    </div>
                </div>
                <div class="actions">
                    <button class="btn btn-primary" onclick="dashboard.downloadFromClient('${client.id}')"
                            ${!this.isClientOnline(client) ? 'disabled' : ''}>
                        <i class="fas fa-download"></i> Download File
                    </button>
                    <button class="btn btn-danger" onclick="dashboard.removeClient('${client.id}')">
                        <i class="fas fa-trash"></i> Remove
                    </button>
                </div>
            </div>
        `).join('');
    }

    renderDownloads() {
        const container = document.getElementById('downloadList');
        
        if (this.downloads.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-clock"></i>
                    <p>No download history</p>
                </div>
            `;
            return;
        }

        container.innerHTML = this.downloads.map(download => `
            <div class="download-item">
                <div class="download-header">
                    <span class="download-id">${download.id}</span>
                    <span class="download-status status-${download.status}">
                        ${download.status}
                    </span>
                </div>
                <div class="download-details">
                    <p><strong>Client:</strong> ${download.clientId}</p>
                    <p><strong>Started:</strong> ${new Date(download.createdAt).toLocaleString()}</p>
                    ${download.completedAt ? 
                        `<p><strong>Completed:</strong> ${new Date(download.completedAt).toLocaleString()}</p>` : ''}
                    ${download.filePath ? 
                        `<p><strong>File:</strong> ${download.filePath}</p>` : ''}
                </div>
            </div>
        `).join('');
    }

    updateStats() {
        const totalClients = this.clients.length;
        const onlineClients = this.clients.filter(client => this.isClientOnline(client)).length;

        document.getElementById('totalClients').textContent = totalClients;
        document.getElementById('onlineClients').textContent = onlineClients;
        document.getElementById('totalDownloads').textContent = this.downloads.length;
        document.getElementById('serverUrl').textContent = this.serverUrl;
    }

    updateClientSelect() {
        const select = document.getElementById('clientSelect');
        const currentValue = select.value;
        
        select.innerHTML = '<option value="">Select a client...</option>' +
            this.clients
                .filter(client => this.isClientOnline(client))
                .map(client => `
                    <option value="${client.id}" ${client.id === currentValue ? 'selected' : ''}>
                        ${client.id} (${client.url})
                    </option>
                `).join('');

        document.getElementById('downloadBtn').disabled = !select.value;
    }

    isClientOnline(client) {
        const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
        return new Date(client.lastSeen).getTime() > fiveMinutesAgo;
    }

    async initiateDownload() {
        const clientId = document.getElementById('clientSelect').value;
        if (!clientId) return;

        await this.downloadFromClient(clientId);
    }

    async downloadFromClient(clientId) {
        const downloadBtn = document.getElementById('downloadBtn');
        const progressSection = document.getElementById('downloadProgress');
        const progressFill = document.getElementById('progressFill');
        const progressText = document.getElementById('progressText');

        // Show progress UI
        downloadBtn.disabled = true;
        progressSection.style.display = 'block';
        progressFill.style.width = '10%';
        progressText.textContent = 'Requesting download from client...';

        try {
            const response = await fetch(`/download/${clientId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            if (data.status === 'success') {
                progressFill.style.width = '100%';
                progressText.textContent = 'Download completed successfully!';
                this.showMessage(`File downloaded successfully from ${clientId}`, 'success');
                
                // Add to download history
                this.downloads.unshift({
                    id: data.requestId,
                    clientId: clientId,
                    status: 'completed',
                    createdAt: Date.now(),
                    completedAt: Date.now(),
                    filePath: data.filePath
                });
                
                this.renderDownloads();
                this.updateStats();
            } else {
                throw new Error(data.error || 'Download failed');
            }

        } catch (error) {
            progressFill.style.width = '100%';
            progressText.textContent = `Download failed: ${error.message}`;
            this.showMessage(`Download failed: ${error.message}`, 'error');
            
            // Add failed download to history
            this.downloads.unshift({
                id: 'req-' + Date.now(),
                clientId: clientId,
                status: 'failed',
                createdAt: Date.now(),
                error: error.message
            });
            
            this.renderDownloads();
        } finally {
            setTimeout(() => {
                progressSection.style.display = 'none';
                downloadBtn.disabled = false;
            }, 3000);
        }
    }

    async removeClient(clientId) {
        if (!confirm(`Are you sure you want to remove client ${clientId}?`)) {
            return;
        }

        try {
            // This would need a DELETE endpoint on the server
            this.showMessage(`Client ${clientId} removed`, 'success');
            this.loadData(); // Refresh the list
        } catch (error) {
            this.showMessage(`Failed to remove client: ${error.message}`, 'error');
        }
    }

    showMessage(text, type = 'success') {
        const messagesContainer = document.getElementById('messages');
        const message = document.createElement('div');
        message.className = `message ${type}`;
        message.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check' : 'exclamation-triangle'}"></i>
            ${text}
        `;
        
        messagesContainer.appendChild(message);
        
        setTimeout(() => {
            message.remove();
        }, 5000);
    }

    startAutoRefresh() {
        // Refresh data every 30 seconds
        setInterval(() => {
            this.loadData();
        }, 30000);
    }
}

// Initialize dashboard when page loads
const dashboard = new FileTransferDashboard();