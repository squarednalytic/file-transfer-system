const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/downloads', express.static(path.join(__dirname, 'downloads')));

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const downloadsDir = path.join(__dirname, 'downloads');
        if (!fs.existsSync(downloadsDir)) {
            fs.mkdirSync(downloadsDir, { recursive: true });
        }
        cb(null, downloadsDir);
    },
    filename: function (req, file, cb) {
        const { requestId } = req.body;
        const originalName = file.originalname;
        const fileName = `${requestId}_${originalName}`;
        cb(null, fileName);
    }
});

const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 200 * 1024 * 1024 // 200MB limit
    }
});


const clients = new Map();
const downloadRequests = new Map();

// Ensure downloads directory exists
const downloadsDir = path.join(__dirname, 'downloads');
if (!fs.existsSync(downloadsDir)) {
    fs.mkdirSync(downloadsDir, { recursive: true });
}


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


app.post('/api/register', (req, res) => {
    const { clientId, clientUrl } = req.body;
    
    if (!clientId || !clientUrl) {
        return res.status(400).json({ error: 'clientId and clientUrl are required' });
    }

    clients.set(clientId, {
        id: clientId,
        url: clientUrl,
        lastSeen: Date.now(),
        status: 'online',
        registeredAt: new Date().toISOString()
    });

    console.log(`Client registered: ${clientId} at ${clientUrl}`);
    res.json({ 
        status: 'registered', 
        clientId,
        message: 'Client registered successfully'
    });
});


app.post('/api/heartbeat', (req, res) => {
    const { clientId } = req.body;
    
    if (clients.has(clientId)) {
        const client = clients.get(clientId);
        client.lastSeen = Date.now();
        client.status = 'online';
        console.log(`Heartbeat from client: ${clientId}`);
    }
    
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});


app.get('/api/clients', (req, res) => {
    const clientList = Array.from(clients.values()).map(client => ({
        id: client.id,
        url: client.url,
        status: client.status,
        lastSeen: client.lastSeen,
        registeredAt: client.registeredAt,
        isOnline: isClientOnline(client)
    }));
    
    res.json({ 
        clients: clientList,
        total: clientList.length,
        online: clientList.filter(client => isClientOnline(client)).length
    });
});


app.get('/api/clients/:clientId', (req, res) => {
    const { clientId } = req.params;
    
    if (!clients.has(clientId)) {
        return res.status(404).json({ error: 'Client not found' });
    }

    const client = clients.get(clientId);
    res.json({
        ...client,
        isOnline: isClientOnline(client)
    });
});


app.post('/api/download/:clientId', async (req, res) => {
    const { clientId } = req.params;
    
    if (!clients.has(clientId)) {
        return res.status(404).json({ error: 'Client not found' });
    }

    const client = clients.get(clientId);
    

    if (!isClientOnline(client)) {
        return res.status(503).json({ error: 'Client is offline' });
    }

    const requestId = uuidv4();

    
    downloadRequests.set(requestId, {
        id: requestId,
        clientId,
        status: 'pending',
        createdAt: Date.now(),
        clientUrl: client.url
    });

    try {
        console.log(`Requesting download from client: ${clientId}, Request ID: ${requestId}`);
        
        
        const response = await axios.post(`${client.url}/api/request-upload`, {
            requestId,
            serverUrl: `http://localhost:${PORT}`
        }, {
            timeout: 10000 // 10 second timeout
        });

        if (response.data.status === 'accepted') {
            
            const request = downloadRequests.get(requestId);
            request.status = 'uploading';
            request.acceptedAt = Date.now();
            
            console.log(`Client ${clientId} accepted download request`);
            
            
            await waitForDownloadCompletion(requestId, res);
        } else {
            downloadRequests.get(requestId).status = 'rejected';
            res.status(500).json({ error: 'Client rejected download request' });
        }
    } catch (error) {
        console.error('Error requesting download from client:', error.message);
        
        const request = downloadRequests.get(requestId);
        request.status = 'failed';
        request.error = error.message;
        request.failedAt = Date.now();
        
        if (error.code === 'ECONNREFUSED') {
            res.status(503).json({ error: 'Cannot connect to client. Client may be offline.' });
        } else if (error.code === 'TIMEOUT') {
            res.status(504).json({ error: 'Request to client timed out' });
        } else {
            res.status(500).json({ error: 'Failed to contact client: ' + error.message });
        }
    }
});


app.post('/api/download-complete', (req, res) => {
    const { requestId, downloadUrl, fileSize, error } = req.body;
    
    if (downloadRequests.has(requestId)) {
        const request = downloadRequests.get(requestId);
        
        if (error) {
            request.status = 'failed';
            request.error = error;
            request.failedAt = Date.now();
            console.log(`Download failed for request: ${requestId}, Error: ${error}`);
        } else {
            request.status = 'completed';
            request.downloadUrl = downloadUrl;
            request.fileSize = fileSize;
            request.completedAt = Date.now();
            console.log(`Download completed for request: ${requestId}, File: ${downloadUrl}`);
        }
    } else {
        console.warn(`Download complete received for unknown request: ${requestId}`);
    }
    
    res.json({ status: 'acknowledged' });
});


app.post('/api/upload-file', upload.single('file'), (req, res) => {
    const { requestId } = req.body;
    
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }

    const finalPath = path.join(downloadsDir, req.file.filename);
    const fileSize = (req.file.size / (1024 * 1024)).toFixed(2); // Size in MB

    if (downloadRequests.has(requestId)) {
        const request = downloadRequests.get(requestId);
        request.status = 'completed';
        request.filePath = finalPath;
        request.downloadUrl = `/downloads/${req.file.filename}`;
        request.fileSize = fileSize;
        request.completedAt = Date.now();
    }

    console.log(`File uploaded successfully for request: ${requestId}, Size: ${fileSize}MB`);

    res.json({ 
        status: 'upload_success', 
        downloadUrl: `/downloads/${req.file.filename}`,
        fileSize: fileSize,
        requestId: requestId
    });
});


app.get('/api/downloads', (req, res) => {
    const downloadList = Array.from(downloadRequests.values())
        .sort((a, b) => b.createdAt - a.createdAt) // Most recent first
        .map(request => ({
            id: request.id,
            clientId: request.clientId,
            status: request.status,
            createdAt: request.createdAt,
            completedAt: request.completedAt,
            failedAt: request.failedAt,
            filePath: request.filePath,
            downloadUrl: request.downloadUrl,
            fileSize: request.fileSize,
            error: request.error
        }));
    
    res.json({ 
        downloads: downloadList,
        total: downloadList.length,
        completed: downloadList.filter(d => d.status === 'completed').length,
        failed: downloadList.filter(d => d.status === 'failed').length,
        pending: downloadList.filter(d => d.status === 'pending' || d.status === 'uploading').length
    });
});


app.get('/api/downloads/:requestId', (req, res) => {
    const { requestId } = req.params;
    
    if (downloadRequests.has(requestId)) {
        res.json(downloadRequests.get(requestId));
    } else {
        res.status(404).json({ error: 'Download request not found' });
    }
});


app.delete('/api/downloads/:requestId', (req, res) => {
    const { requestId } = req.params;
    
    if (downloadRequests.has(requestId)) {
        const request = downloadRequests.get(requestId);
        
        // Delete the actual file if it exists
        if (request.filePath && fs.existsSync(request.filePath)) {
            fs.unlinkSync(request.filePath);
        }
        
        downloadRequests.delete(requestId);
        res.json({ status: 'deleted', requestId });
    } else {
        res.status(404).json({ error: 'Download request not found' });
    }
});


app.delete('/api/clients/:clientId', (req, res) => {
    const { clientId } = req.params;
    
    if (clients.has(clientId)) {
        clients.delete(clientId);
        res.json({ status: 'deleted', clientId, message: 'Client removed successfully' });
    } else {
        res.status(404).json({ error: 'Client not found' });
    }
});


app.get('/api/status', (req, res) => {
    const clientList = Array.from(clients.values());
    const onlineClients = clientList.filter(client => isClientOnline(client));
    const downloadList = Array.from(downloadRequests.values());
    
    res.json({
        server: {
            status: 'online',
            uptime: process.uptime(),
            port: PORT,
            timestamp: new Date().toISOString()
        },
        clients: {
            total: clientList.length,
            online: onlineClients.length,
            offline: clientList.length - onlineClients.length
        },
        downloads: {
            total: downloadList.length,
            completed: downloadList.filter(d => d.status === 'completed').length,
            failed: downloadList.filter(d => d.status === 'failed').length,
            pending: downloadList.filter(d => d.status === 'pending' || d.status === 'uploading').length
        },
        storage: {
            downloadsDir: downloadsDir,
            exists: fs.existsSync(downloadsDir)
        }
    });
});


function isClientOnline(client) {
    const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
    return client.lastSeen > fiveMinutesAgo;
}

async function waitForDownloadCompletion(requestId, res) {
    const maxWaitTime = 300000; // 5 minutes
    const checkInterval = 2000; // 2 seconds
    const startTime = Date.now();
    
    console.log(`Waiting for download completion for request: ${requestId}`);
    
    while (Date.now() - startTime < maxWaitTime) {
        const request = downloadRequests.get(requestId);
        
        if (request.status === 'completed') {
            console.log(`Download completed successfully for request: ${requestId}`);
            return res.json({
                status: 'success',
                requestId,
                downloadUrl: request.downloadUrl,
                filePath: request.filePath,
                fileSize: request.fileSize,
                clientId: request.clientId,
                duration: Date.now() - request.createdAt
            });
        }
        
        if (request.status === 'failed') {
            console.log(`Download failed for request: ${requestId}, Error: ${request.error}`);
            return res.status(500).json({ 
                error: 'Download failed: ' + (request.error || 'Unknown error'),
                requestId 
            });
        }
        
        
        await new Promise(resolve => setTimeout(resolve, checkInterval));
    }
    

    const request = downloadRequests.get(requestId);
    request.status = 'timeout';
    request.error = 'Download timeout';
    request.failedAt = Date.now();
    
    console.log(`Download timeout for request: ${requestId}`);
    res.status(408).json({ 
        error: 'Download timeout - client did not complete upload within 5 minutes',
        requestId 
    });
}


setInterval(() => {
    const now = Date.now();
    const inactiveTime = 300000; // 5 minutes
    
    for (const [clientId, client] of clients.entries()) {
        if (now - client.lastSeen > inactiveTime) {
            client.status = 'offline';
            console.log(`Marked client as offline: ${clientId}`);
        }
    }
}, 60000); // Check every minute


setInterval(() => {
    const downloadArray = Array.from(downloadRequests.entries());
    if (downloadArray.length > 100) {
        // Sort by creation time and remove oldest
        downloadArray.sort((a, b) => a[1].createdAt - b[1].createdAt);
        const toRemove = downloadArray.slice(0, downloadArray.length - 100);
        
        toRemove.forEach(([requestId, request]) => {
            // Delete the actual file if it exists
            if (request.filePath && fs.existsSync(request.filePath)) {
                try {
                    fs.unlinkSync(request.filePath);
                } catch (error) {
                    console.error(`Error deleting file ${request.filePath}:`, error.message);
                }
            }
            downloadRequests.delete(requestId);
        });
        
        console.log(`Cleaned up ${toRemove.length} old download requests`);
    }
}, 300000); // Check every 5 minutes


app.use((error, req, res, next) => {
    console.error('Unhandled error:', error);
    res.status(500).json({ 
        error: 'Internal server error',
        message: error.message 
    });
});


app.use('/api/*', (req, res) => {
    res.status(404).json({ error: 'API endpoint not found' });
});


app.listen(PORT, () => {
    console.log(`🚀 File Transfer Server running on port ${PORT}`);
    console.log(`📊 Dashboard available at: http://localhost:${PORT}`);
    console.log(`📁 Downloads directory: ${downloadsDir}`);
    console.log(`🔌 API endpoints available under: http://localhost:${PORT}/api/`);
    console.log('--- Available API Endpoints ---');
    console.log('GET  /api/clients           - List all clients');
    console.log('POST /api/register          - Register a client');
    console.log('POST /api/download/:clientId - Download file from client');
    console.log('GET  /api/downloads         - List download requests');
    console.log('GET  /api/status            - System status');
    console.log('--------------------------------');
});


process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down server gracefully...');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n🛑 Server terminated');
    process.exit(0);
});

module.exports = app;